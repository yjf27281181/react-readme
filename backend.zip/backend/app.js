const express = require("express");
const app = express();
const questionRouter = require("./router/question");
const userRouter = require("./router/user");
const commentRouter = require("./router/comment");
const pdfRouter = require("./router/pdf");
const bodyParser = require("body-parser");




app.use(
  bodyParser.urlencoded({
    extended: false
  })
);
app.use(bodyParser.json());



app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, content-type, Accept, authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT,PATCH, DELETE, OPTIONS"
  );
  next();
});

app.use("/api/user", userRouter);
app.use("/api/question", questionRouter);
app.use("/api/comment", commentRouter);
app.use("/api/pdf", pdfRouter);
module.exports = app;