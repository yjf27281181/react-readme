const express = require('express');
const router = express.Router();
const questionController = require('../controller/question');
//const checkAuth = require('../middleware/check-auth');

// router.post("/create", userController.create)

router.get("/get",
questionController.getQuestions);

router.post("/post",
questionController.postQuestion);


module.exports = router;
