const express = require('express');
const router = express.Router();
const pdfController = require('../controller/pdf');
//const checkAuth = require('../middleware/check-auth');

// router.post("/create", userController.create)

router.get("/get/:courseName",
pdfController.getPDFNames);


module.exports = router;