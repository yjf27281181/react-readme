const express = require('express');
const router = express.Router();
const userController = require('../controller/user');
const checkAuth = require('../middleware/check-auth');

// router.post("/create", userController.create)

router.post("/login",
userController.login);

router.post("/register",
userController.register);

router.get("/userInfo",checkAuth,
userController.userAuth);


module.exports = router;