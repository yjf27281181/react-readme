
module.exports = {

  'jwtsecret': 'myjwttest',
  'url': "localhost"
};