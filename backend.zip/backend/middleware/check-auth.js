const jwt = require('jsonwebtoken')
const conf = require("../conf")

module.exports = (req, res, next) => {
  try {
    const token = req.headers.authorization;
    const decodedToken = jwt.verify(token, conf.jwtsecret);
    req.userInfo = {username: decodedToken.username, userId: decodedToken.userId};
    next();
  } catch(error) {
    res.status(401).json({ message: "Auth failed"});
  }
}
