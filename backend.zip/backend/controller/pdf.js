db = require("../db");

exports.getPDFNames = function(req, res, next) {
  courseName = req.params.courseName;
  connect = db.connection();
  sql = `select * from course where course_name='${courseName}'`;
  connect.query(sql, function(err, result) {
    pdfNames = [];
    for(i in result) {
        pdfNames.push(result[i].pdf_name)
    }
    db.close(connect);
    res
      .status(201)
      .json({
        message: "sucess find the pdfNames",
        courseName: courseName,
        pdfNames: pdfNames,
        code: 0
      });
  });
};
