db = require("../db");
const { responseClient } = require("../util");

exports.postComment = function(req, res, next) {
    data = req.body;
    console.log(data)
    connect = db.connection();
    sql = `INSERT INTO comment(author_id, question_id,  create_time, like_num, content) `+
    `VALUES (${data.authorId}, ${data.questionId}, '${new Date().toJSON().slice(0, 19).replace('T', ' ')}', ${10}, ` +
    `'${data.content}')`
    console.log(sql);
    connect.query(sql, function(err, result) {
      if(err) {
        console.log(err)
          responseClient(res, 500, 1, "an error occur in database");
      }
      db.close(connect);
      if (result) {
        console.log(result);
        responseClient(res, 200, 0, "insert success", data);
        return;
      } else {
        responseClient(res, 400, 1, "insert question wrong");
      }
    });
  
};

exports.getComments = function(req, res, next) {
    questionId = req.params.questionId;
    console.log(questionId)
    connect = db.connection();
    sql = `select username, c.create_time, content, like_num from comment c  left join user on c.author_id=user.id where question_id='${questionId}'`;
    console.log(sql);
    connect.query( sql, function(err, result) {
      console.log(result);
      db.close(connect);
      res.status(201).json({ message: "sucess find the questions", comments: result, code: 0});
    });
    
  };