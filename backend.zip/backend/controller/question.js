db = require("../db");
const { responseClient } = require("../util");
exports.getQuestions = function(req, res, next) {
  pdfName = req.query.pdfName;
  pageNum = req.query.pageNum;
  connect = db.connection();
  sql = `select * from question where pdf_name='${pdfName}' and page_num=${pageNum}`;
  connect.query(sql, function(err, result) {
    console.log(result);
    db.close(connect);
    res
      .status(201)
      .json({
        message: "sucess find the questions",
        questions: result,
        code: 0
      });
  });
};

exports.postQuestion = function(req, res, next) {
  data = req.body;
  console.log(data);
  connect = db.connection();
  sql =
    `INSERT INTO question(title, content, pdf_name, page_num, pos_x, pos_y, author_id, create_time, like_num) ` +
    `VALUES ('${data.title}', '${data.content}', '${data.pdfName}', ${
      data.pageNum
    }, ` +
    `${data.posX}, ${data.posY}, ${data.authorId}, '${new Date()
      .toJSON()
      .slice(0, 19)
      .replace("T", " ")}', 20)`;
  connect.query(sql, function(err, result) {
    db.close(connect);
    if (err) {
      console.log(err);
      responseClient(res, 500, 1, "an error occur in database");
      return;
    }

    if (result) {
      console.log(result);
      responseClient(res, 200, 0, "insert success", data);
      return;
    } else {
      responseClient(res, 400, 1, "insert question wrong");
    }
  });
};
