db = require("../db");
const conf = require("../conf")
const {MD5_SUFFIX, responseClient, md5} = require("../util");
const jwt = require('jsonwebtoken')


exports.login = function(req, res, next) {
  let { username, password } = req.body;

  if (!username) {
    responseClient(res, 400, 2, "username is empty");
    return;
  }
  if (!password) {
    responseClient(res, 400, 2, "password is empty");
    return;
  }
  connect = db.connection();
  connect.query(
    `select * from user where username='${username}' and pass_word='${md5(
      password + MD5_SUFFIX
    )}'`,
    function(err, userInfo) {
      if (err) {
        console.log(err)
        responseClient(res, 500, 1, "an error occur in database");
        return;
      }
      db.close(connect);
      console.log(userInfo)
      if (userInfo[0]) {
        let data = {};
        data.username = userInfo[0].username;
        data.userId = userInfo[0].id;
        //set session after login
        const token = jwt.sign(
          {username:data.username, userId: data.userId},
          conf.jwtsecret,
          {expiresIn: "24h"}
        );
        data.token = token;
        responseClient(res, 200, 0, "login success", data);
        return;
      } else {
        responseClient(res, 400, 1, "username or password is wrong");
      }
    }
  );
};

exports.register = function(req, res, next) {
  let { username, password } = req.body;

  if (!username) {
    responseClient(res, 400, 2, "username is empty");
    return;
  }
  if (!password) {
    responseClient(res, 400, 2, "password is empty");
    return;
  }
  connect = db.connection();
  const sql = `insert into user(username, pass_word, create_time) values ('${username}', '${md5(
    password + MD5_SUFFIX
  )}',
  '${new Date()
    .toJSON()
    .slice(0, 19)
    .replace("T", " ")}')`;
  connect.query(sql, function(err, info) {
    if (err) {
      db.close(connect);
      responseClient(res, 500, 1, "username has been used");
      return;
    }
    db.close(connect);
    if (info) {
      var data = {};
      data.info = info;
      responseClient(res, 200, 0, "login success", data);
      return;
    } else {
      responseClient(res, 400, 1, "username or password is wrong");
    }
  });
};

//用户验证
exports.userAuth =function (req,res,next) {
  console.log("---------------------")
  console.log(req.userInfo)
  if(req.userInfo){
      responseClient(res,200,0,'',req.userInfo)
  }else{
      responseClient(res,200,1,'please login again',req.userInfo)
  }
};

// router.get('/logout',function (req,res) {
//   req.session.destroy();
//   res.redirect('/');
// });

