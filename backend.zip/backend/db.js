const mysql = require('mysql');
let db = {}
const conf = require('./conf')


db.close = function(connection){
    connection.end(function(err){
        if(err){
            return;
        }else{
            console.log('closed connection with database');
        }
    });
}

db.connection = function(){
    let connection = mysql.createConnection({
        host: conf.url,
        user:'root',
        password:'root',
        database:'readwithme',
        port:3306
    });
    connection.connect(function(err){
        if(err){
            console.log(err);
            return;
        }
    });
    return connection;
}
module.exports = db;